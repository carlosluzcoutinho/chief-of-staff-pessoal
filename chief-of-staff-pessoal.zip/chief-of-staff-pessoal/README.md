# Chief of Staff Pessoal

Um prompt para transformar qualquer IA de chat (Claude, ChatGPT, Gemini etc.) em um segundo cérebro pessoal: memória organizada, rotinas diárias e cobrança de prioridades, adaptado à rotina real de quem usa.

Não é um prompt de produto, de vendas ou de qualquer profissão específica. O sistema é montado a partir de um discovery guiado, usando o vocabulário e as tarefas de quem está configurando.

## O que o sistema faz

- Guarda contexto durável sobre você: pessoas, projetos, rotinas, prazos.
- Roda rotinas diárias e semanais (abrir o dia, fechar o dia, preparar uma conversa, processar uma reunião, revisão semanal).
- Cobra prioridades e prazos com firmeza, sem culpa.
- Aprende e aplica a sua voz de escrita ao longo do tempo.
- Se adapta à profissão e à rotina de quem está configurando, sem modelo fixo.

## Como usar

1. Copie todo o conteúdo de [`PROMPT.md`](./PROMPT.md).
2. Cole em uma conversa nova com uma IA. Funciona melhor em ambientes com acesso a arquivos (Claude Code, Claude com Projects, Cowork ou equivalentes), mas também roda em um chat comum.
3. Quando a IA perguntar, escolha o modo:
   - **Modo A:** começar do zero. A IA faz um discovery guiado em 7 blocos.
   - **Modo B:** você já tem histórico de conversas, memórias exportadas ou notas. Anexe o material e a IA extrai o que já sabe antes de perguntar o que falta.
4. Reserve de 30 a 45 minutos para o primeiro setup. Revise com calma cada proposta antes de aprovar.

## Estrutura que o sistema cria

```
/
  CLAUDE.md                 instruções principais de comportamento
  CRITICAL_FACTS.md         memória de trabalho (uma página, sempre atual)
  navegacao.md              índice do que existe e onde
  memory/                   logs diários
  pessoas/                  um arquivo por pessoa
  areas/                    unidades de trabalho e áreas de vida
  voz/                      como você escreve, por público
  skills/                   rotinas universais e sob medida
```

Em ambientes sem acesso a arquivos, a IA entrega o mesmo conteúdo como dois documentos: um de instruções e um de contexto, para colar nas instruções e no conhecimento do projeto.

## Princípios

- Franqueza acima de validação. O sistema aponta furos, não concorda por educação.
- Fato confirmado é diferente de hipótese. Nada é gravado como certo sem você confirmar.
- Nada de persona genérica de profissão. As skills nascem do que você realmente faz no dia a dia.
- Privacidade por padrão: sem dados de identidade, sem números de conta, sem dados sensíveis de terceiros.

## Compatibilidade

Testado com foco em Claude, mas o prompt não depende de nenhuma ferramenta proprietária. Funciona em qualquer IA de chat com boa capacidade de seguir instruções longas e, idealmente, com memória persistente entre conversas (arquivos, projetos ou plugins de memória).

## Contribuindo

Sugestões e ajustes são bem-vindos via issue ou pull request. Ideias de skills sob medida para profissões específicas são particularmente úteis como exemplos, desde que fique claro que são exemplos e não parte obrigatória do prompt.

## Licença

MIT. Use, adapte e redistribua livremente.
